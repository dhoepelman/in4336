#!/bin/bash

export PATH=`pwd`/z3/bin:$PATH
